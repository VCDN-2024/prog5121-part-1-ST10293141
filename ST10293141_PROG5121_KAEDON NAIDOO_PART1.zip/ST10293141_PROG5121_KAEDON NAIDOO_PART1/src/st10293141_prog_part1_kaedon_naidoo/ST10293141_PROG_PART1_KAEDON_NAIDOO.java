
package st10293141_prog_part1_kaedon_naidoo;
import javax.swing.JOptionPane;

public class ST10293141_PROG_PART1_KAEDON_NAIDOO {

    public static void main(String[] args) {
       
        Register u = new Register();
        u.Credentials();
        u.checkUsername();
        u.checkPassword();
        
        Login l = new Login();
        l.checkLoginUsername();
        l.checkLoginPassword();
        
        // Calling specific variables from another class and assigning them to another variable
        String RegUsername = u.username;
        String RegPassword = u.password;
        String firstname = u.name;
        String lastname = u.surname;
        
        String LoginUsername = l.LogUsername;
        String LoginPassword = l.LogPassword;
       
        
        boolean check = false;
        // A while loop that checks whether the user logged in with the correct information
        while(!check || LoginUsername.isEmpty() || LoginPassword.isEmpty()){
            if(RegUsername.equals(LoginUsername) && RegPassword.equals(LoginPassword)){
                JOptionPane.showMessageDialog(null,"Hello " + firstname + " " + lastname +  "\nGood to see you again");
                check = true;
            
            }
            else{
                JOptionPane.showMessageDialog(null,"Username or Password incorrcect, please try again");
                l.checkLoginUsername(); // allows for re-entry of username
                l.checkLoginPassword(); // allows for re-entry of password
                LoginUsername = l.LogUsername;
                LoginPassword = l.LogPassword;
                check = false;
            }
            
        }
    }
}


//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1