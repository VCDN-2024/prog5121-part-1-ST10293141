
package st10293141_prog_part1_kaedon_naidoo;
import javax.swing.JOptionPane;

public class Login {
    // Declaration of public variables
    public String LogUsername = "";
    public String LogPassword = "";

    // A method that allows the user to input their username to login
    public void checkLoginUsername() {
        JOptionPane.showMessageDialog(null, "Registration is finished, please log in");

        // Loop until a non-empty username is provided
        while (LogUsername.trim().isEmpty()) {
            LogUsername = JOptionPane.showInputDialog("Please enter your username: ");
            if(LogUsername == null) {
                // User clicked 'Cancel'
                // Handle the situation, either exit the program or provide feedback
                // For example:
                JOptionPane.showMessageDialog(null, "You need to provide a username to log in.");
            }
        }
    }

    // A method that allows the user to input their password to login
    public void checkLoginPassword() {
        // Loop until a non-empty password is provided
        while (LogPassword.trim().isEmpty()) {
            LogPassword = JOptionPane.showInputDialog("Please enter your password: ");
            if(LogPassword == null) {
                // User clicked 'Cancel'
                // Handle the situation, either exit the program or provide feedback
                // For example:
                JOptionPane.showMessageDialog(null, "You need to provide a password to log in.");
            }
        }
    }
    

    // Method to validate the login credentials
    public boolean validateLogin(String RegUsername, String RegPassword) {
        if (LogUsername.equals(RegUsername) && LogPassword.equals(RegPassword)) {
            System.out.println("Login Successful");
            return true;
        } else {
            System.out.println("Login Failed. Incorrect username or password.");
            return false;
        }
    }

   
}
